# Emmy Noether — Mathematical works in English

Papers 1–43, the 1929/30 lectures written up by M. Deuring, the Kapferer–Noether work and supplement, bibliography and terminal lists.

Build each listed main file twice from its own directory with XeLaTeX; Arabic and Persian use LuaLaTeX. Keep the archive directory structure. Required packages and fonts are declared in the preambles.

- `noether.tex`

[Authorship and rights](RIGHTS.md).
