# Emmy Noether — Mathematical works in English

Papers 1–43, the 1929/30 lectures written up by M. Deuring, the Kapferer–Noether work and supplement, bibliography and terminal lists.

The direct cumulative LaTeX contains every source body and its preamble as editable text. Run the supplied Python program to extract the native files and compile them with XeLaTeX; the program joins the component PDFs in reading order. It does not use scans or PDF pages as transcription. The ZIP preserves the native structure, the same cumulative LaTeX, and the build program. Install Python 3, pypdf and the TeX packages and fonts named in the source preambles. PDF bytes can vary with TeX and font versions. The fixed internal typesetting date is not the publication date.

```text
python -m pip install pypdf
python build.py 02-noether-en-base.tex --output 01-noether-en-base.pdf
```

Build program created by AI: OpenAI Codex — GPT-6 Astra, Ultra, 24 October 2026.

AI-translated text. Corrections and typesetting produced by OpenAI Codex — GPT-6 Astra, Ultra effort. The mathematical authors remain those named in the works, including Emmy Noether, M. Deuring and the named coauthors. No human translation or independent human review is attributed to the publisher.

The exact model and effort used for the inherited translation have not been established from the surviving production records. AI-produced corrections and typesetting: 23–24 October 2026; Claude Opus 5.5 (Anthropic), 26 October 2026, including the formulas aligned with the German text as read from Noether's printed pages. Edition: 26 October 2026.
