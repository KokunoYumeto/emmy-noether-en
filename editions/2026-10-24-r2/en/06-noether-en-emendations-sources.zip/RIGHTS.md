# Authorship and rights

AI-translated text. Corrections and typesetting produced by OpenAI Codex — GPT-6 Astra, Ultra effort. The mathematical authors remain those named in the works, including Emmy Noether, M. Deuring and the named coauthors. No human translation or independent human review is attributed to the publisher.

The exact model and effort used for the inherited translation have not been established from the surviving production records. AI-produced corrections and typesetting: 23–24 October 2026; Claude Opus 5.5 (Anthropic), 26 October 2026, including the formulas aligned with the German text as read from Noether's printed pages. Edition: 26 October 2026.

Emmy Noether's writings are in the public domain. To the extent the publisher holds any rights in the AI-produced translation, corrections and typesetting, they are dedicated to the public domain under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). The lectures written up by M. Deuring, the work of H. Kapferer and the contributions of the named coauthors keep their own legal status.

[Rights-holder objections](https://github.com/KokunoYumeto/emmy-noether-en/issues/new).
